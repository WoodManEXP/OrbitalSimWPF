﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrbitalSimWPF
{
    public class Body
    {
        public Boolean Selected { get; set; }
        public String ID { get; }
        public String Name { get; }
        public String Designation { get; }
        public String IAU_Alias { get; }
        public String MassStr { get; }
        public String GM_Str { get; }

        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double VX { get; set;}
        public double VY { get; set;}
        public double VZ { get; set;}
        public double LT { get; set;}
        public double RG { get; set; }
        public double RR { get; set; }
        public double Mass { get; set;}
        public double GM { get; set; }


        public Body(Boolean selected        /* 1 */
                    , String ID             /* 2 */
                    , String name           /* 3 */
                    , String designation    /* 4 */
                    , String IAU_Alias      /* 5 */
                    , String massStr        /* 6 */
                    , String GM_Str)        /* 7 */
        {

            this.Selected = selected;
            this.ID = ID;
            this.Name = name;
            this.Designation = designation;
            this.IAU_Alias = IAU_Alias;
            this.MassStr = massStr;
            this.GM_Str = GM_Str;

            // Mass and GM values to double

            double dVal;
            Mass = double.TryParse(massStr, out dVal) ? dVal : -1D;
            GM = double.TryParse(GM_Str, out dVal) ? dVal : -1D;

        }

        public String ToCSV_String()
        {

            // Use,InitSel,ID#,Name,Designation,IAU/aliases/other,Mass,GM

            String comma = ",";

            // Bodies.Add(new Body("y".Equals(col[1]), col[2], col[3], col[4], col[5], col[6], col[7]));
            return new String("y" + comma + (Selected ? "y" : "n") + comma + ID + comma + Name + comma + Designation
                +comma + IAU_Alias + comma + MassStr + comma + GM_Str);

        }
    }
}
