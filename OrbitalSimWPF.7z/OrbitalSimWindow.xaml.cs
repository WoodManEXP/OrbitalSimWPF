﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Media3D;

namespace OrbitalSimWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        BodyList BodyList { get; }
        private SimCamera SimCamera { get; set; }
        SimModel? SimModel { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            stopButton.IsEnabled = false;
            continueButton.IsEnabled = false;

            //String aStr = Properties.Settings.Default.BodiesCSVFile;
            //MessageBox.Show(aStr);

            // Prep the bodies list
            String bodiesCSVFile = Properties.Settings.Default.BodiesCSVFile;
            String savedBodiesCSVFile = Properties.Settings.Default.SimBodiesCSVFile;
            try
            {
                BodyList = new BodyList(bodiesCSVFile, savedBodiesCSVFile);
            }
            catch (Exception ex)
            {
                String aMsg = ex.Message + " " + Properties.Settings.Default.NoBodiesCSVFile + ": " + bodiesCSVFile;
                MessageBox.Show(aMsg, "Oops");
                Environment.Exit(0);
            }

        }

        private void Menu_FileExit(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Button_Bodies(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Button_Bodies");

            bodiesButton.IsEnabled = true;
            continueButton.IsEnabled = false;
            stopButton.IsEnabled = false;
            startButton.IsEnabled = true;

            var dialog = new BodiesListDialog(BodyList);

            bool? result = dialog.ShowDialog();
        }

        private void Button_Start(object sender, RoutedEventArgs e)
        {
            startButton.IsEnabled = false;
            bodiesButton.IsEnabled = false;
            continueButton.IsEnabled = false;
            stopButton.IsEnabled = true;

            // Read the ephemerides from JPL
            //var dialog = new EphemerisReader(BodyList);
            //bool? result = dialog.ShowDialog();

            // Instantiate model elements
            SimModel = new();
            SimModel.InitScene(SimViewport);

            // Instantiate camera
            // https://stackoverflow.com/questions/28656442/cameraposition-and-lookdirection-in-wpf
            Point3D cameraPos = new(16.0E06D, 2.0E06D, 16.0E06D);
            Point3D lookAtPos = new(0D, 2E00D, 0D);
            Vector3D lookDir = new(lookAtPos.X-cameraPos.X, lookAtPos.Y - cameraPos.Y, lookAtPos.Z - cameraPos.Z);
            lookDir.Normalize();

            // Synthesize an upDir. Right hand rule, want Y coord to be positive (thumb up)
            Vector3D upDir = new(0D, 1D, 0D);
            upDir = Vector3D.CrossProduct(lookDir, upDir); // Initial upDir
            upDir = Vector3D.CrossProduct(upDir, lookDir);
            upDir.Normalize();

            SimCamera = new(SimModel
                          , cameraPos   // Camera's location in the 3D scene
                          , lookDir     // Direction that the camera is pointing
                          , upDir       // Camera's initial up direction
                          , 60D);       // Camera's horizontal field of view in degrees

            // Asign the camera to the viewport
            SimViewport.Camera = SimCamera.Camera;

        }

        private void Button_Stop(object sender, RoutedEventArgs e)
        {
            stopButton.IsEnabled = false;
            continueButton.IsEnabled = true;
            bodiesButton.IsEnabled = true;
        }

        private void Button_Continue(object sender, RoutedEventArgs e)
        {
            startButton.IsEnabled = false;
            bodiesButton.IsEnabled = false;
            continueButton.IsEnabled = false;
            stopButton.IsEnabled = true;
        }

        // Create the scene
        // SimViewport is the Viewport3D defined in the xaml file that displays everything
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        /// <summary>
        /// e.Delta + is roll forward, - is roll back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SimViewportGrid_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            SimCamera.Move((e.Delta > 0) ? SimCamera.MoveDirection.MoveForward : SimCamera.MoveDirection.MoveBackward);
        }

        /// <summary>
        /// Grid containing Viewport3D must have focus before keys flow its way.
        /// Key: Down, Up, LEft, Right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SimViewportGrid_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool look = (e.KeyboardDevice.Modifiers == ModifierKeys.Control | e.KeyboardDevice.Modifiers == ModifierKeys.Alt);

            switch (e.Key)
            {
                case System.Windows.Input.Key.Up:
                    if (look)
                        SimCamera.Look(0D, 1D);
                    else
                        SimCamera.Move(SimCamera.MoveDirection.MoveUp);
                    e.Handled = true;
                    break;
                case System.Windows.Input.Key.Down:
                    if (look)
                        SimCamera.Look(0D, -1D);
                    else
                        SimCamera.Move(SimCamera.MoveDirection.MoveDown);
                    e.Handled = true;
                    break;
                case System.Windows.Input.Key.Left:
                    if (look)
                        SimCamera.Look(1D, 0D);
                    else
                        SimCamera.Move(SimCamera.MoveDirection.MoveLeft);
                    e.Handled = true;
                    break;
                case System.Windows.Input.Key.Right:
                    if (look)
                        SimCamera.Look(-1D, 0D);
                    else
                        SimCamera.Move(SimCamera.MoveDirection.MoveRight);
                    e.Handled = true;
                    break;
                default:
                    break;
            }

        }

        Boolean ChangingLook = false;
        Point LastMousePt { get; set; }

        private void SimViewportGrid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {

            ChangingLook = true;

            LastMousePt = e.GetPosition(this);

            Point p = e.GetPosition(this);

            //System.Diagnostics.Debug.WriteLine("SimViewportGrid_MouseDown " + p.X + " " + p.Y);
        }

        private void SimViewportGrid_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {

            if (!ChangingLook || null == SimCamera)
                return;

            const double minDegrees = 1D, maxDegrees = 5D;

            Point p = e.GetPosition(this);

            double dX = p.X - LastMousePt.X;
            double dY = p.Y - LastMousePt.Y;
            LastMousePt = p;

            SimCamera.Look(-Math.Sign(dX) * Math.Min(Math.Abs(minDegrees * dX), maxDegrees)        // Max +- maxDegrees
                            , -Math.Sign(dY) * Math.Min(Math.Abs(minDegrees * dY), maxDegrees));   // Max +- maxDegrees

            //System.Diagnostics.Debug.WriteLine("SimViewportGrid_MouseMove " + dX + " " + dY);
        }

        private void SimViewportGrid_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ChangingLook)
                return;

            ChangingLook = false;

            Point p = e.GetPosition(this);

            //System.Diagnostics.Debug.WriteLine("SimViewportGrid_MouseUp " + p.X + " " + p.Y);
        }
    }
}
